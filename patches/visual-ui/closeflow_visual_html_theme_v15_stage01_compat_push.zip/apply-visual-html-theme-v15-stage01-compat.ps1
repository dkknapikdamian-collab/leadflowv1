$ErrorActionPreference = "Stop"

$Repo = "C:\Users\malim\Desktop\biznesy_ai\2.closeflow"
$Branch = "dev-rollout-freeze"
$ZipArchiveName = "closeflow_visual_html_theme_v15_stage01_compat_push.zip"
$ZipArchivePath = Join-Path $HOME ("Downloads\" + $ZipArchiveName)

function Write-Utf8NoBomFile([string]$Path, [string]$Content) {
  $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $Content, $Utf8NoBom)
}

function Read-Utf8Clean([string]$Path) {
  $Content = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
  if ($Content.Length -gt 0 -and [int][char]$Content[0] -eq 0xFEFF) {
    $Content = $Content.Substring(1)
  }
  return $Content
}

function Run-Step([string]$Label, [scriptblock]$Block) {
  Write-Host ("== " + $Label + " ==")
  & $Block
  if ($LASTEXITCODE -ne 0) {
    throw "STOP: command failed in step: $Label, exit code: $LASTEXITCODE"
  }
}

Set-Location $Repo

$currentBranch = git branch --show-current
if ($currentBranch -ne $Branch) {
  throw "STOP: jestes na galezi $currentBranch, a wymagana jest $Branch"
}

Run-Step "repair Layout Stage01 compatibility without touching logic" {
  $LayoutPath = "src\components\Layout.tsx"
  if (!(Test-Path $LayoutPath)) {
    throw "STOP: nie ma pliku $LayoutPath"
  }

  $Layout = Read-Utf8Clean $LayoutPath

  if ($Layout -notlike "*VISUAL_HTML_THEME_V15_STAGE01_GUARD_COMPAT*") {
    $CompatComment = "/* VISUAL_HTML_THEME_V15_STAGE01_GUARD_COMPAT keeps legacy guard text: className=`"app closeflow-visual-stage01`" */`r`n"
    $Layout = $CompatComment + $Layout
  }

  $Layout = $Layout.Replace('className="app closeflow-visual-stage01 cf-html-shell cf-html-shell"', 'className="app closeflow-visual-stage01 cf-html-shell"')
  $Layout = $Layout.Replace('className="app cf-html-shell closeflow-visual-stage01"', 'className="app closeflow-visual-stage01 cf-html-shell"')
  $Layout = $Layout.Replace('className="app cf-html-shell closeflow-visual-stage01 cf-html-shell"', 'className="app closeflow-visual-stage01 cf-html-shell"')

  if ($Layout -like '*className="app closeflow-visual-stage01"*' -and $Layout -notlike '*className="app closeflow-visual-stage01 cf-html-shell"*') {
    $Layout = $Layout.Replace('className="app closeflow-visual-stage01"', 'className="app closeflow-visual-stage01 cf-html-shell"')
  }

  if ($Layout -notlike '*cf-html-shell*') {
    throw "STOP: Layout nie ma cf-html-shell po naprawie"
  }

  if ($Layout -notlike '*className="app closeflow-visual-stage01"*') {
    throw "STOP: Layout nie ma tekstu kompatybilnosci dla Stage01 guard"
  }

  if ($Layout -like '*Panel domykania leadów*') {
    $Layout = $Layout.Replace('Panel domykania leadów', 'Lead &rarr; klient &rarr; sprawa')
  }
  if ($Layout -like '*Panel domykania leadow*') {
    $Layout = $Layout.Replace('Panel domykania leadow', 'Lead &rarr; klient &rarr; sprawa')
  }

  Write-Utf8NoBomFile $LayoutPath $Layout
  Write-Host "OK: Layout ma cf-html-shell i zachowuje stary tekst klasy dla Stage01 guard"
}

Run-Step "repair package.json no BOM" {
  $PkgPath = "package.json"
  $PkgRaw = Read-Utf8Clean $PkgPath
  $Pkg = $PkgRaw | ConvertFrom-Json
  if (-not $Pkg.scripts) {
    $Pkg | Add-Member -MemberType NoteProperty -Name scripts -Value ([pscustomobject]@{})
  }
  $Pkg.scripts | Add-Member -MemberType NoteProperty -Name "check:visual-html-theme-v14" -Value "node scripts/check-visual-html-theme-v14.cjs" -Force
  $Guard = "node scripts/check-visual-html-theme-v14.cjs"
  $CurrentLint = [string]$Pkg.scripts.lint
  if ([string]::IsNullOrWhiteSpace($CurrentLint)) {
    $Pkg.scripts.lint = $Guard
  } elseif ($CurrentLint -notlike ("*" + $Guard + "*")) {
    $Pkg.scripts.lint = $Guard + " && " + $CurrentLint
  }
  $Json = $Pkg | ConvertTo-Json -Depth 50
  Write-Utf8NoBomFile $PkgPath ($Json + "`r`n")
  node -e "JSON.parse(require('fs').readFileSync('package.json','utf8')); console.log('OK package.json valid JSON')"
}

Run-Step "archive v15 zip in repo" {
  if (Test-Path $ZipArchivePath) {
    New-Item -ItemType Directory -Force -Path "patches\visual-ui" | Out-Null
    Copy-Item -Force $ZipArchivePath (Join-Path "patches\visual-ui" $ZipArchiveName)
    Write-Host "OK: ZIP v15 skopiowany do patches\visual-ui"
  } else {
    Write-Host "INFO: ZIP v15 nie znaleziony w Downloads, pomijam archiwizacje ZIP-a w repo"
  }
}

Run-Step "run focused guards" {
  npm.cmd run check:visual-stage01-shell
  npm.cmd run check:visual-html-theme-v14
}

Run-Step "run polish check" {
  npm.cmd run check:polish
}

Run-Step "run build" {
  npm.cmd run build
}

Run-Step "run lint" {
  npm.cmd run lint
}

Run-Step "run quiet verify" {
  npm.cmd run verify:closeflow:quiet
}

Run-Step "commit and push" {
  git status --short
  git add package.json src/index.css src/components/Layout.tsx src/styles/visual-html-theme-v14.css scripts/check-visual-html-theme-v14.cjs docs/VISUAL_HTML_THEME_V14.md
  if (Test-Path (Join-Path "patches\visual-ui" "closeflow_visual_html_theme_v14_reset_apply_push.zip")) {
    git add (Join-Path "patches\visual-ui" "closeflow_visual_html_theme_v14_reset_apply_push.zip")
  }
  if (Test-Path (Join-Path "patches\visual-ui" $ZipArchiveName)) {
    git add (Join-Path "patches\visual-ui" $ZipArchiveName)
  }
  $AfterAdd = git status --short
  if ($AfterAdd) {
    git commit -m "Apply visual HTML theme v14 with Stage01 compatibility"
    git push origin $Branch
  } else {
    Write-Host "OK: brak zmian do commita"
  }
}

Write-Host "== GOTOWE: v15 naprawilo guard Stage01, testy przeszly, commit/push wykonany jesli byly zmiany. =="
