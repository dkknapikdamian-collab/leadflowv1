# VISUAL HTML THEME V15 STAGE01 COMPAT

Cel: naprawić wyłącznie zgodność guardu Stage 01 po v14.

Zakres:
- nie resetuje repo ponownie,
- nie dotyka logiki aplikacji,
- nie przerabia Cases.tsx,
- zachowuje `cf-html-shell`,
- dodaje tekst kompatybilności wymagany przez stary guard `check-visual-stage01-shell.cjs`,
- odpala pełne lokalne bramki i robi commit + push na `dev-rollout-freeze`.
