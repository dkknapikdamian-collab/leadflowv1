# CloseFlow — Visual Stage 01 Shell i sidebar

Ta paczka wdraża pierwszy etap przebudowy UI:

- ciemny sidebar,
- grupy menu,
- globalny pasek akcji,
- mobile-top,
- mobile-nav,
- wspólny CSS shell,
- guard `check:visual-stage01-shell`,
- dokumentację mapowania funkcji.

Nie zmienia logiki biznesowej, Supabase, auth, billing, API ani ekranów wewnętrznych.

## Jedno polecenie PowerShell

```powershell
$ZipPath = "$HOME\Downloads\closeflow_visual_stage01_shell_sidebar_2026-04-28.zip"; $Temp = "$HOME\Downloads\closeflow_visual_stage01_shell_sidebar_2026-04-28_unpacked"; if (Test-Path $Temp) { Remove-Item -Recurse -Force $Temp }; Expand-Archive -Force $ZipPath $Temp; powershell -ExecutionPolicy Bypass -File "$Temp\apply-visual-stage01.ps1"
```

## Polecenie bez builda, jeśli chcesz najpierw tylko nałożyć pliki

```powershell
$ZipPath = "$HOME\Downloads\closeflow_visual_stage01_shell_sidebar_2026-04-28.zip"; $Temp = "$HOME\Downloads\closeflow_visual_stage01_shell_sidebar_2026-04-28_unpacked"; if (Test-Path $Temp) { Remove-Item -Recurse -Force $Temp }; Expand-Archive -Force $ZipPath $Temp; powershell -ExecutionPolicy Bypass -File "$Temp\apply-visual-stage01.ps1" -SkipBuild
```

## Po pozytywnym sprawdzeniu

```powershell
cd "C:\Users\malim\Desktop\biznesy_ai\2.closeflow"
git status --short
git add src/components/Layout.tsx src/components/GlobalQuickActions.tsx src/styles/visual-stage01-shell.css src/index.css scripts/check-visual-stage01-shell.cjs package.json docs/VISUAL_STAGE_01_SHELL_SIDEBAR_2026-04-28.md
git commit -m "Visual Stage 01 shell sidebar"
git push origin dev-rollout-freeze
```

## Ręczne kliknięcia po wdrożeniu

1. `/` — sprawdź Dziś i podświetlenie aktywnego linku.
2. `/leads`, `/clients`, `/cases`, `/tasks`, `/calendar`, `/activity`, `/ai-drafts`, `/notifications`, `/billing`, `/help`, `/settings`.
3. Kliknij globalnie: AI, Szybki szkic, Szkice AI, Lead, Zadanie, Wydarzenie.
4. Zmniejsz ekran poniżej 760px i sprawdź mobile-top, mobile drawer i mobile-nav.
