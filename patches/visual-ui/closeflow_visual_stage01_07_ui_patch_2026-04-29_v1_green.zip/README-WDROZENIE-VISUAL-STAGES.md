# CloseFlow Visual UI Stages 01-04

Ta paczka jest rosnącym patchem UI. Nie jest pełnym repo. Nakłada kolejne etapy przebudowy wizualnej zgodnie z HTML-em `closeflow_full_app_modern_5s_ui_concept.html` i nie zmienia logiki biznesowej, Supabase, auth ani billing/access.

## Zawartość

- Visual Stage 01 — Shell i sidebar
- Visual Stage 02 — Dziś
- Visual Stage 03 — Leady
- Visual Stage 04 — LeadDetail

## Jedno polecenie

```powershell
$ZipPath = "$HOME\Downloads\closeflow_visual_stage01_shell_sidebar_2026-04-28.zip"; $Temp = "$HOME\Downloads\closeflow_visual_stage01_shell_sidebar_2026-04-28_unpacked"; if (Test-Path $Temp) { Remove-Item -Recurse -Force $Temp }; Expand-Archive -Force $ZipPath $Temp; powershell -ExecutionPolicy Bypass -File "$Temp\apply-visual-stages.ps1"
```

## Co odpala skrypt

- `check:visual-stage01-shell`
- `check:visual-stage02-today`
- `check:visual-stage03-leads`
- `check:visual-stage04-lead-detail`
- `check:polish`
- `npm run build`
- `npm run lint`
- `npm run verify:closeflow:quiet`

## Ręczna kontrola Stage 04

- `/leads/:leadId`
- edycja leada
- zmiana statusu
- rozpoczęcie obsługi
- otwarcie sprawy
- szybkie zadanie
- szybkie wydarzenie
- notatki
- powiązane taski/eventy
- zakładki
- mobile poniżej 760px


## Visual Stage 05 — Klienci
Dodany scope `/clients`, CSS, guard i raport mapowania. Logika listy klientów, kosza, tworzenia i linków pozostaje bez zmian.


## Visual Stage 06 — ClientDetail
Dodany scope `/clients/:clientId`, CSS, guard i raport mapowania. Logika karty klienta, relacji, edycji i synchronizacji pozostaje bez zmian.


## HOTFIX 2026-04-29 guard compatibility

Poprawiono guardy Stage 02 i Stage 04, aby pasowaly do aktualnego Layout.tsx z currentSection oraz regex route detection dla LeadDetail. Dodatkowo skrypt kopiuje dokumenty Stage 05-06 i uruchamia guardy Stage 05-06 bezposrednio.


## Visual Stage 07 — Sprawy

Paczka zawiera etap wizualnego mapowania listy spraw na docelowy system HTML. Logika Supabase, tworzenia spraw, usuwania spraw, lifecycle, filtrów i routingu pozostaje bez zmian.

Guard: `npm run check:visual-stage07-cases`.
