param(
  [string]$Repo = "C:\Users\malim\Desktop\biznesy_ai\2.closeflow",
  [string]$Branch = "dev-rollout-freeze",
  [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$FilesRoot = Join-Path $PatchRoot "files"

Write-Host "== CloseFlow Visual Stages 01-02 ==" -ForegroundColor Cyan
Write-Host "Repo: $Repo"
Write-Host "Branch: $Branch"

if (!(Test-Path $Repo)) {
  throw "STOP: Nie znaleziono repo: $Repo"
}

Set-Location $Repo

if (!(Test-Path "package.json")) {
  throw "STOP: To nie wygląda jak katalog repo CloseFlow. Brak package.json."
}

$currentBranch = git branch --show-current
if ($currentBranch -ne $Branch) {
  throw "STOP: Jesteś na gałęzi '$currentBranch', a wymagane jest '$Branch'."
}

$beforeStatus = git status --short
if ($beforeStatus) {
  Write-Host "== UWAGA: repo ma lokalne zmiany przed patchem ==" -ForegroundColor Yellow
  $beforeStatus | ForEach-Object { Write-Host $_ }
}

Write-Host "== Kopiuję pliki etapów ==" -ForegroundColor Cyan
$copyMap = @(
  @{ Source = "src\components\Layout.tsx"; Target = "src\components\Layout.tsx" },
  @{ Source = "src\components\GlobalQuickActions.tsx"; Target = "src\components\GlobalQuickActions.tsx" },
  @{ Source = "src\styles\visual-stage01-shell.css"; Target = "src\styles\visual-stage01-shell.css" },
  @{ Source = "src\styles\visual-stage02-today.css"; Target = "src\styles\visual-stage02-today.css" },
  @{ Source = "scripts\check-visual-stage01-shell.cjs"; Target = "scripts\check-visual-stage01-shell.cjs" },
  @{ Source = "scripts\check-visual-stage02-today.cjs"; Target = "scripts\check-visual-stage02-today.cjs" },
  @{ Source = "docs\VISUAL_STAGE_01_SHELL_SIDEBAR_2026-04-28.md"; Target = "docs\VISUAL_STAGE_01_SHELL_SIDEBAR_2026-04-28.md" },
  @{ Source = "docs\VISUAL_STAGE_02_TODAY_2026-04-28.md"; Target = "docs\VISUAL_STAGE_02_TODAY_2026-04-28.md" }
)

foreach ($item in $copyMap) {
  $src = Join-Path $FilesRoot $item.Source
  $dst = Join-Path $Repo $item.Target
  $dstDir = Split-Path -Parent $dst
  if (!(Test-Path $src)) {
    throw "STOP: Brak pliku w paczce: $src"
  }
  if (!(Test-Path $dstDir)) {
    New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
  }
  Copy-Item -Force $src $dst
  Write-Host "OK: $($item.Target)"
}

Write-Host "== Aktualizuję src/index.css ==" -ForegroundColor Cyan
$indexPath = Join-Path $Repo "src\index.css"
$indexText = Get-Content $indexPath -Raw
$importsToEnsure = @(
  '@import "./styles/visual-stage01-shell.css";',
  '@import "./styles/visual-stage02-today.css";'
)

foreach ($stageImport in $importsToEnsure) {
  if ($indexText -notlike "*$stageImport*") {
    $anchor = '@import "./styles/closeflow-case-detail-focus.css";'
    if ($indexText -like "*$anchor*") {
      $indexText = $indexText.Replace($anchor, "$anchor`r`n$stageImport")
    } else {
      $firstImport = '@import "tailwindcss";'
      $indexText = $indexText.Replace($firstImport, "$firstImport`r`n$stageImport")
    }
    Write-Host "OK: dodano import $stageImport"
  } else {
    Write-Host "OK: import już istnieje: $stageImport"
  }
}
[System.IO.File]::WriteAllText($indexPath, $indexText, $Utf8NoBom)

Write-Host "== Aktualizuję package.json ==" -ForegroundColor Cyan
$packagePath = Join-Path $Repo "package.json"
$pkg = Get-Content $packagePath -Raw | ConvertFrom-Json
if (-not $pkg.scripts) {
  $pkg | Add-Member -MemberType NoteProperty -Name scripts -Value ([pscustomobject]@{})
}

$scriptMap = @{
  "check:visual-stage01-shell" = "node scripts/check-visual-stage01-shell.cjs"
  "check:visual-stage02-today" = "node scripts/check-visual-stage02-today.cjs"
}

$scriptNames = @($pkg.scripts.PSObject.Properties.Name)
foreach ($name in $scriptMap.Keys) {
  if ($scriptNames -notcontains $name) {
    $pkg.scripts | Add-Member -MemberType NoteProperty -Name $name -Value $scriptMap[$name]
    Write-Host "OK: dodano skrypt $name"
  } else {
    Write-Host "OK: skrypt $name już istnieje"
  }
}

$lintValue = [string]$pkg.scripts.lint
if ($lintValue -notmatch "check-visual-stage01-shell\.cjs") {
  $pkg.scripts.lint = "node scripts/check-visual-stage01-shell.cjs && $lintValue"
  $lintValue = [string]$pkg.scripts.lint
  Write-Host "OK: dopięto guard Stage 01 do npm run lint"
} else {
  Write-Host "OK: guard Stage 01 jest już w npm run lint"
}

if ($lintValue -notmatch "check-visual-stage02-today\.cjs") {
  $pkg.scripts.lint = "node scripts/check-visual-stage02-today.cjs && $lintValue"
  Write-Host "OK: dopięto guard Stage 02 do npm run lint"
} else {
  Write-Host "OK: guard Stage 02 jest już w npm run lint"
}

$packageJson = $pkg | ConvertTo-Json -Depth 50
[System.IO.File]::WriteAllText($packagePath, $packageJson, $Utf8NoBom)

Write-Host "== Uruchamiam guard Stage 01 ==" -ForegroundColor Cyan
npm.cmd run check:visual-stage01-shell

Write-Host "== Uruchamiam guard Stage 02 ==" -ForegroundColor Cyan
npm.cmd run check:visual-stage02-today

Write-Host "== Uruchamiam kontrolę polskich znaków ==" -ForegroundColor Cyan
npm.cmd run check:polish

if (-not $SkipBuild) {
  Write-Host "== Uruchamiam build ==" -ForegroundColor Cyan
  npm.cmd run build
} else {
  Write-Host "== Pomijam build, bo podano -SkipBuild ==" -ForegroundColor Yellow
}

Write-Host "== Status po patchu ==" -ForegroundColor Cyan
git status --short

Write-Host "== Gotowe: Visual Stage 01-02 nałożone lokalnie. Po testach możesz zrobić commit i push. ==" -ForegroundColor Green
