param(
  [string]$Repo = "C:\Users\malim\Desktop\biznesy_ai\2.closeflow"
)

$ErrorActionPreference = "Stop"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$PackagePath = Join-Path $Repo "package.json"

if (!(Test-Path $PackagePath)) {
  throw "STOP: Brak package.json w $Repo"
}

$text = [System.IO.File]::ReadAllText($PackagePath, [System.Text.Encoding]::UTF8).TrimStart([char]0xFEFF)
$json = $text | ConvertFrom-Json
$normalized = $json | ConvertTo-Json -Depth 50
[System.IO.File]::WriteAllText($PackagePath, $normalized, $Utf8NoBom)

Write-Host "OK: package.json zapisany jako UTF-8 bez BOM."
