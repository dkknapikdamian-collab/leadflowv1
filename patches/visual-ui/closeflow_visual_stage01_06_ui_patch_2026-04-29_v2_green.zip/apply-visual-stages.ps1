param(
  [string]$Repo = "C:\Users\malim\Desktop\biznesy_ai\2.closeflow",
  [string]$Branch = "dev-rollout-freeze",
  [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"
$PatchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$FilesRoot = Join-Path $PatchRoot "files"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function ReadTextNoBom([string]$Path) {
  $text = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
  return $text.TrimStart([char]0xFEFF)
}
function WriteTextNoBom([string]$Path, [string]$Text) {
  [System.IO.File]::WriteAllText($Path, $Text, $Utf8NoBom)
}
function CopyTextNoBom([string]$Source, [string]$Target) {
  $text = ReadTextNoBom $Source
  WriteTextNoBom $Target $text
}
function StripBomIfPresent([string]$Path) {
  if (!(Test-Path $Path)) { return }
  $bytes = [System.IO.File]::ReadAllBytes($Path)
  if ($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191) {
    $text = ReadTextNoBom $Path
    WriteTextNoBom $Path $text
    Write-Host "OK: usunieto BOM z $Path"
  }
}

Write-Host "== CloseFlow Visual Stages 01-06 ==" -ForegroundColor Cyan
Write-Host "Repo: $Repo"
Write-Host "Branch: $Branch"

if (!(Test-Path $Repo)) { throw "STOP: Nie znaleziono repo: $Repo" }
Set-Location $Repo
if (!(Test-Path "package.json")) { throw "STOP: To nie wyglada jak katalog repo CloseFlow. Brak package.json." }
$currentBranch = git branch --show-current
if ($currentBranch -ne $Branch) { throw "STOP: Jestes na galezi '$currentBranch', a wymagane jest '$Branch'." }

$beforeStatus = git status --short
if ($beforeStatus) {
  Write-Host "== UWAGA: repo ma lokalne zmiany przed patchem ==" -ForegroundColor Yellow
  $beforeStatus | ForEach-Object { Write-Host $_ }
}

Write-Host "== Kopiuje pliki etapow ==" -ForegroundColor Cyan
$copyMap = @(
  @{ Source = "src\components\Layout.tsx"; Target = "src\components\Layout.tsx" },
  @{ Source = "src\components\GlobalQuickActions.tsx"; Target = "src\components\GlobalQuickActions.tsx" },
  @{ Source = "src\styles\visual-stage01-shell.css"; Target = "src\styles\visual-stage01-shell.css" },
  @{ Source = "src\styles\visual-stage02-today.css"; Target = "src\styles\visual-stage02-today.css" },
  @{ Source = "src\styles\visual-stage03-leads.css"; Target = "src\styles\visual-stage03-leads.css" },
  @{ Source = "src\styles\visual-stage04-lead-detail.css"; Target = "src\styles\visual-stage04-lead-detail.css" },
  @{ Source = "src\styles\visual-stage05-clients.css"; Target = "src\styles\visual-stage05-clients.css" },
  @{ Source = "src\styles\visual-stage06-client-detail.css"; Target = "src\styles\visual-stage06-client-detail.css" },
  @{ Source = "scripts\check-visual-stage01-shell.cjs"; Target = "scripts\check-visual-stage01-shell.cjs" },
  @{ Source = "scripts\check-visual-stage02-today.cjs"; Target = "scripts\check-visual-stage02-today.cjs" },
  @{ Source = "scripts\check-visual-stage03-leads.cjs"; Target = "scripts\check-visual-stage03-leads.cjs" },
  @{ Source = "scripts\check-visual-stage04-lead-detail.cjs"; Target = "scripts\check-visual-stage04-lead-detail.cjs" },
  @{ Source = "scripts\check-visual-stage05-clients.cjs"; Target = "scripts\check-visual-stage05-clients.cjs" },
  @{ Source = "scripts\check-visual-stage06-client-detail.cjs"; Target = "scripts\check-visual-stage06-client-detail.cjs" },
  @{ Source = "docs\VISUAL_STAGE_01_SHELL_SIDEBAR_2026-04-28.md"; Target = "docs\VISUAL_STAGE_01_SHELL_SIDEBAR_2026-04-28.md" },
  @{ Source = "docs\VISUAL_STAGE_02_TODAY_2026-04-28.md"; Target = "docs\VISUAL_STAGE_02_TODAY_2026-04-28.md" },
  @{ Source = "docs\VISUAL_STAGE_03_LEADS_2026-04-28.md"; Target = "docs\VISUAL_STAGE_03_LEADS_2026-04-28.md" },
  @{ Source = "docs\VISUAL_STAGE_04_LEAD_DETAIL_2026-04-28.md"; Target = "docs\VISUAL_STAGE_04_LEAD_DETAIL_2026-04-28.md" },
  @{ Source = "docs\VISUAL_STAGE_05_CLIENTS_2026-04-28.md"; Target = "docs\VISUAL_STAGE_05_CLIENTS_2026-04-28.md" },
  @{ Source = "docs\VISUAL_STAGE_06_CLIENT_DETAIL_2026-04-28.md"; Target = "docs\VISUAL_STAGE_06_CLIENT_DETAIL_2026-04-28.md" }
)
foreach ($item in $copyMap) {
  $src = Join-Path $FilesRoot $item.Source
  $dst = Join-Path $Repo $item.Target
  $dstDir = Split-Path -Parent $dst
  if (!(Test-Path $src)) { throw "STOP: Brak pliku w paczce: $src" }
  if (!(Test-Path $dstDir)) { New-Item -ItemType Directory -Force -Path $dstDir | Out-Null }
  CopyTextNoBom $src $dst
  Write-Host "OK: $($item.Target)"
}

Write-Host "== Aktualizuje src/index.css ==" -ForegroundColor Cyan
$indexPath = Join-Path $Repo "src\index.css"
$indexText = ReadTextNoBom $indexPath
$importsToEnsure = @(
  '@import "./styles/visual-stage01-shell.css";',
  '@import "./styles/visual-stage02-today.css";',
  '@import "./styles/visual-stage03-leads.css";',
  '@import "./styles/visual-stage04-lead-detail.css";',
  '@import "./styles/visual-stage05-clients.css";',
  '@import "./styles/visual-stage06-client-detail.css";'
)
foreach ($stageImport in $importsToEnsure) {
  if ($indexText -notlike "*$stageImport*") {
    $anchor = '@import "./styles/closeflow-case-detail-focus.css";'
    if ($indexText -like "*$anchor*") { $indexText = $indexText.Replace($anchor, "$anchor`r`n$stageImport") }
    else { $indexText = '@import "tailwindcss";' + "`r`n" + $stageImport + "`r`n" + ($indexText -replace '@import "tailwindcss";\s*','') }
    Write-Host "OK: dodano import $stageImport"
  } else { Write-Host "OK: import juz istnieje: $stageImport" }
}
WriteTextNoBom $indexPath $indexText

Write-Host "== Aktualizuje package.json ==" -ForegroundColor Cyan
$packagePath = Join-Path $Repo "package.json"
StripBomIfPresent $packagePath
$pkg = ReadTextNoBom $packagePath | ConvertFrom-Json
if (-not $pkg.scripts) { $pkg | Add-Member -MemberType NoteProperty -Name scripts -Value ([pscustomobject]@{}) }
$scriptMap = @{
  "check:visual-stage01-shell" = "node scripts/check-visual-stage01-shell.cjs"
  "check:visual-stage02-today" = "node scripts/check-visual-stage02-today.cjs"
  "check:visual-stage03-leads" = "node scripts/check-visual-stage03-leads.cjs"
  "check:visual-stage04-lead-detail" = "node scripts/check-visual-stage04-lead-detail.cjs"
  "check:visual-stage05-clients" = "node scripts/check-visual-stage05-clients.cjs"
  "check:visual-stage06-client-detail" = "node scripts/check-visual-stage06-client-detail.cjs"
}
$scriptNames = @($pkg.scripts.PSObject.Properties.Name)
foreach ($name in $scriptMap.Keys) {
  if ($scriptNames -notcontains $name) { $pkg.scripts | Add-Member -MemberType NoteProperty -Name $name -Value $scriptMap[$name]; Write-Host "OK: dodano skrypt $name" }
  else { Write-Host "OK: skrypt $name juz istnieje" }
}
foreach ($guard in @("check-visual-stage01-shell.cjs", "check-visual-stage02-today.cjs", "check-visual-stage03-leads.cjs", "check-visual-stage04-lead-detail.cjs")) {
  $lintValue = [string]$pkg.scripts.lint
  if ($lintValue -notmatch [regex]::Escape($guard)) {
    $pkg.scripts.lint = "node scripts/$guard && $lintValue"
    Write-Host "OK: dopieto guard $guard do npm run lint"
  } else { Write-Host "OK: guard $guard jest juz w npm run lint" }
}

$lintValue = [string]$pkg.scripts.lint
if ($lintValue -notmatch "check-visual-stage05-clients\.cjs") {
  $pkg.scripts.lint = "node scripts/check-visual-stage05-clients.cjs && $lintValue"
  Write-Host "OK: dopieto guard Stage 05 do npm run lint"
} else {
  Write-Host "OK: guard Stage 05 jest juz w npm run lint"
}

$lintValue = [string]$pkg.scripts.lint
if ($lintValue -notmatch "check-visual-stage06-client-detail\.cjs") {
  $pkg.scripts.lint = "node scripts/check-visual-stage06-client-detail.cjs && $lintValue"
  Write-Host "OK: dopieto guard Stage 06 do npm run lint"
} else {
  Write-Host "OK: guard Stage 06 jest juz w npm run lint"
}

$packageJson = $pkg | ConvertTo-Json -Depth 50
WriteTextNoBom $packagePath $packageJson
StripBomIfPresent $packagePath

Write-Host "== Uruchamiam guard Stage 01 ==" -ForegroundColor Cyan
npm.cmd run check:visual-stage01-shell
Write-Host "== Uruchamiam guard Stage 02 ==" -ForegroundColor Cyan
npm.cmd run check:visual-stage02-today
Write-Host "== Uruchamiam guard Stage 03 ==" -ForegroundColor Cyan
npm.cmd run check:visual-stage03-leads
Write-Host "== Uruchamiam guard Stage 04 ==" -ForegroundColor Cyan
npm.cmd run check:visual-stage04-lead-detail
Write-Host "== Uruchamiam guard Stage 05 ==" -ForegroundColor Cyan
npm.cmd run check:visual-stage05-clients
Write-Host "== Uruchamiam guard Stage 06 ==" -ForegroundColor Cyan
npm.cmd run check:visual-stage06-client-detail
Write-Host "== Uruchamiam kontrole polskich znakow ==" -ForegroundColor Cyan
npm.cmd run check:polish

if (-not $SkipBuild) {
  Write-Host "== Uruchamiam build ==" -ForegroundColor Cyan
  npm.cmd run build
  Write-Host "== Uruchamiam pelny lint ==" -ForegroundColor Cyan
  npm.cmd run lint
  Write-Host "== Uruchamiam pelny quiet verify ==" -ForegroundColor Cyan
  npm.cmd run verify:closeflow:quiet
} else { Write-Host "== Pomijam build/lint/verify, bo podano -SkipBuild ==" -ForegroundColor Yellow }

Write-Host "== Status po patchu ==" -ForegroundColor Cyan
git status --short
Write-Host "== Gotowe: Visual Stage 01-06 nalozone lokalnie. Po zielonych testach mozesz dalej dopinac etapy albo finalnie zrobic commit/push. ==" -ForegroundColor Green
