$ErrorActionPreference = "Stop"

$Repo = "C:\Users\malim\Desktop\biznesy_ai\2.closeflow"
$Branch = "dev-rollout-freeze"
$ZipArchiveName = "closeflow_visual_html_theme_v14_reset_apply_push.zip"
$ZipArchivePath = Join-Path $HOME ("Downloads\" + $ZipArchiveName)
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Utf8NoBomFile([string]$Path, [string]$Content) {
  $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $Content, $Utf8NoBom)
}

function Read-Utf8Clean([string]$Path) {
  $Content = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
  if ($Content.Length -gt 0 -and [int][char]$Content[0] -eq 0xFEFF) {
    $Content = $Content.Substring(1)
  }
  return $Content
}

function Run-Step([string]$Label, [scriptblock]$Block) {
  Write-Host ("== " + $Label + " ==")
  & $Block
  if ($LASTEXITCODE -ne 0) {
    throw "STOP: command failed in step: $Label, exit code: $LASTEXITCODE"
  }
}

Set-Location $Repo

$currentBranch = git branch --show-current
if ($currentBranch -ne $Branch) {
  throw "STOP: jestes na galezi $currentBranch, a wymagana jest $Branch"
}

Run-Step "backup dirty state and reset to origin" {
  git fetch origin
  $Status = git status --short
  if ($Status) {
    $Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $BackupPatch = Join-Path $HOME ("Downloads\closeflow_failed_visual_local_state_" + $Stamp + ".patch")
    git diff > $BackupPatch
    Write-Host ("OK: zapisano backup lokalnego diff: " + $BackupPatch)
  }
  git reset --hard ("origin/" + $Branch)
  git clean -fd
}

Run-Step "copy v14 files" {
  New-Item -ItemType Directory -Force -Path "src\styles" | Out-Null
  New-Item -ItemType Directory -Force -Path "scripts" | Out-Null
  New-Item -ItemType Directory -Force -Path "docs" | Out-Null
  Copy-Item -Force (Join-Path $ScriptRoot "src\styles\visual-html-theme-v14.css") "src\styles\visual-html-theme-v14.css"
  Copy-Item -Force (Join-Path $ScriptRoot "scripts\check-visual-html-theme-v14.cjs") "scripts\check-visual-html-theme-v14.cjs"
  Copy-Item -Force (Join-Path $ScriptRoot "docs\VISUAL_HTML_THEME_V14.md") "docs\VISUAL_HTML_THEME_V14.md"
  if (Test-Path $ZipArchivePath) {
    New-Item -ItemType Directory -Force -Path "patches\visual-ui" | Out-Null
    Copy-Item -Force $ZipArchivePath (Join-Path "patches\visual-ui" $ZipArchiveName)
    Write-Host "OK: ZIP skopiowany do patches\visual-ui"
  } else {
    Write-Host "INFO: ZIP nie znaleziony w Downloads, pomijam archiwizacje ZIP-a w repo"
  }
}

Run-Step "repair src/index.css import" {
  $IndexPath = "src\index.css"
  $Index = Read-Utf8Clean $IndexPath
  $Import = '@import "./styles/visual-html-theme-v14.css";'
  if ($Index -notlike ("*" + $Import + "*")) {
    $Index = $Index.TrimEnd() + "`r`n" + $Import + "`r`n"
  }
  Write-Utf8NoBomFile $IndexPath $Index
  Write-Host "OK: index.css ma import v14"
}

Run-Step "repair Layout.tsx shell class and subtitle" {
  $LayoutPath = "src\components\Layout.tsx"
  $Layout = Read-Utf8Clean $LayoutPath
  if ($Layout -notlike "*VISUAL_HTML_THEME_V14_LAYOUT*") {
    $Layout = "/* VISUAL_HTML_THEME_V14_LAYOUT */`r`n" + $Layout
  }
  $Layout = $Layout.Replace('className="app closeflow-visual-stage01"', 'className="app closeflow-visual-stage01 cf-html-shell"')
  $Layout = $Layout.Replace('className="app closeflow-visual-stage01 cf-html-shell cf-html-shell"', 'className="app closeflow-visual-stage01 cf-html-shell"')
  $Layout = $Layout.Replace('Panel domykania leadów', 'Lead &rarr; klient &rarr; sprawa')
  $Layout = $Layout.Replace('Panel domykania leadow', 'Lead &rarr; klient &rarr; sprawa')
  $Layout = $Layout.Replace('Menu aplikacji', 'Lead &rarr; klient &rarr; sprawa')
  Write-Utf8NoBomFile $LayoutPath $Layout
  Write-Host "OK: Layout ma cf-html-shell i brand subtitle"
}

Run-Step "repair package.json no BOM and lint hook" {
  $PkgPath = "package.json"
  $PkgRaw = Read-Utf8Clean $PkgPath
  $Pkg = $PkgRaw | ConvertFrom-Json
  if (-not $Pkg.scripts) {
    $Pkg | Add-Member -MemberType NoteProperty -Name scripts -Value ([pscustomobject]@{})
  }
  $Pkg.scripts | Add-Member -MemberType NoteProperty -Name "check:visual-html-theme-v14" -Value "node scripts/check-visual-html-theme-v14.cjs" -Force
  $Guard = "node scripts/check-visual-html-theme-v14.cjs"
  $CurrentLint = [string]$Pkg.scripts.lint
  if ([string]::IsNullOrWhiteSpace($CurrentLint)) {
    $Pkg.scripts.lint = $Guard
  } elseif ($CurrentLint -notlike ("*" + $Guard + "*")) {
    $Pkg.scripts.lint = $Guard + " && " + $CurrentLint
  }
  $Json = $Pkg | ConvertTo-Json -Depth 50
  Write-Utf8NoBomFile $PkgPath ($Json + "`r`n")
  node -e "JSON.parse(require('fs').readFileSync('package.json','utf8')); console.log('OK package.json valid JSON')"
}

Run-Step "run focused visual guard" {
  npm.cmd run check:visual-html-theme-v14
}

Run-Step "run polish check" {
  npm.cmd run check:polish
}

Run-Step "run build" {
  npm.cmd run build
}

Run-Step "run lint" {
  npm.cmd run lint
}

Run-Step "run quiet verify" {
  npm.cmd run verify:closeflow:quiet
}

Run-Step "commit and push" {
  git status --short
  git add package.json src/index.css src/components/Layout.tsx src/styles/visual-html-theme-v14.css scripts/check-visual-html-theme-v14.cjs docs/VISUAL_HTML_THEME_V14.md
  if (Test-Path (Join-Path "patches\visual-ui" $ZipArchiveName)) {
    git add (Join-Path "patches\visual-ui" $ZipArchiveName)
  }
  $AfterAdd = git status --short
  if ($AfterAdd) {
    git commit -m "Apply visual HTML theme v14"
    git push origin $Branch
  } else {
    Write-Host "OK: brak zmian do commita"
  }
}

Write-Host "== GOTOWE: v14 zastosowane, sprawdzone, commit/push wykonany jezeli byly zmiany. =="
